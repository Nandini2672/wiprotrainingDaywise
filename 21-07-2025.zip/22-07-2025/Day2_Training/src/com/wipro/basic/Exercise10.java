package com.wipro.basic;

public class Exercise10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;

        for (int i = 2; i <= 100; i=i+ 2) {
            sum = sum+ i;
        }

        System.out.println("Sum of even numbers from 1 to 100 is: " + sum);

	}

}
