package com.wipro.basic;

import java.util.Date ;

public class FormData2 {

	public static void main(String[] args) {
		String productName = "Racing Bike ";
		short productNumber = 12;
		String model = "RX-100";
		String category = "Bicycle";
		String subcategory = "Bikes";
		String productLine = "Pro Series";
		String productClass = "RX";
		String style = "long curve";
		String color = "Red";
		String size = "Medium";
		String weight = "25.2 kg";

		double listPrice = 18899.99;
		double standardCost = 18520.50;

		Date sellStartDate = null;
		Date sellEndDate = null;
		Date discountDate = null;

		int safetyStock = 150;
		int reorderPoint = 100;
		int daysToManufacture = 14;

		boolean isFinishedGoods = true;

	}

}
