package com.wipro.basic;

public class Exercise8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 5; 

        if (num % 2 == 0) {
            System.out.println("Number is even");
        } else {
            System.out.println("Number is odd");
        }

	}

}
