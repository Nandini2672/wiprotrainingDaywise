package com.wipro.basic;

public class Exercise9_Loops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<=10;i=i+2)
		{
			System.out.println(i);
		}

	}

}
