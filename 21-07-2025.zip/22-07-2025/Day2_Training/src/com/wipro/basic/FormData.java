package com.wipro.basic;

public class FormData {

	public static void main(String args[]) {
		String fullName = "Shubham Rama Bhoite";
		String dateOfBirth = "2002-04-15";
		char gender = 'M';
		long phoneNumber = 9876543210L;
		String email = "shubham.bhoite@gmail.com";
		String heardFrom = "Google";

		short numberOfTickets = 2;
		String paymentMethod = "Credit Card";
		boolean understood=true;
		String signature = "Shubham R. Bhoite";
		String dateSigned = "2025-07-22";

	}
}
