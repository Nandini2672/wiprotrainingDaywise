package com.wipro.oops.test;

import com.wipro.oops.Restaurant;

public class RestaurantTest {
	public static void main(String[] args) {
        Restaurant restaurant = new Restaurant("R001", "Amit Verma", 4.5);

        System.out.println(restaurant);
    }

}
