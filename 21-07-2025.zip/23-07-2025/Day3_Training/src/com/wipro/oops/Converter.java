package com.wipro.oops;

public class Converter {
	
	public int convert(int a) {
		return a*a;
		
	}
	public int convert(int a, int b) {
		return a-b;
		
	}
	public double convert(double a) {
		return a/2;
		
	}

}


