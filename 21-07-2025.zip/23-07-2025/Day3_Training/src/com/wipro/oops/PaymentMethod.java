package com.wipro.oops;

public interface PaymentMethod {
	void pay(double amount);

}
