import { Component } from '@angular/core';

@Component({
  selector: 'app-display-list',
  imports: [],
  templateUrl: './display-list.html',
  styleUrl: './display-list.css'
})
export class DisplayList {

}
