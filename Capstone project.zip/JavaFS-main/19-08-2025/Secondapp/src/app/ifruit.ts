export interface IFruit {
    imgSrc :string;
    name:string;
    desc:string;
}
