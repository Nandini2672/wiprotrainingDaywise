export interface ITask {
    id:number;
    description:string;
    category:string;
}
