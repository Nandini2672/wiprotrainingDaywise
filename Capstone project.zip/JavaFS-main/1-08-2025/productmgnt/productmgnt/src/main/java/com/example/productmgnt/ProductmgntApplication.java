package com.example.productmgnt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductmgntApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductmgntApplication.class, args);
	}

}
