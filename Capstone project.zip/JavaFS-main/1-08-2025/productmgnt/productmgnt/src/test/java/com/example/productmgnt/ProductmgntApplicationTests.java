package com.example.productmgnt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductmgntApplicationTests {

	@Test
	void contextLoads() {
	}

}
