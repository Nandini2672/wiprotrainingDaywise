package com.wipro.firstboot.service.impl;

import java.util.List;

public interface Cityimpl {
	List<String> getCityList();
}
