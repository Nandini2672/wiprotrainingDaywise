package com.wipro.webmvcv1.service;

import java.util.List;

public interface CarService {
	List<String> getCarList();

}




