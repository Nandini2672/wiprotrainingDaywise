let dt = new Date("2030-08-13");
const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const dayName = days[dt.getDay()]; 
console.log(dt);
console.log(dayName); 