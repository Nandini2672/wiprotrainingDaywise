function show(){
    str = document.getElementById("inp").value;
    console.log(str.length);
}
function fn1(){
    str = document.getElementById("inp").value;
    console.log(str);
}