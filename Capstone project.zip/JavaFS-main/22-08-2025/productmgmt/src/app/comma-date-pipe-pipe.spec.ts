import { CommaDatePipePipe } from './comma-date-pipe-pipe';

describe('CommaDatePipePipe', () => {
  it('create an instance', () => {
    const pipe = new CommaDatePipePipe();
    expect(pipe).toBeTruthy();
  });
});
