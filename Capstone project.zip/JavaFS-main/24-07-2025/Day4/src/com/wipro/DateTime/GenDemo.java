package com.wipro.DateTime;

public class GenDemo<T> {
	T t;
	void printit(T t) {
		System.out.println(t);
	}

}
