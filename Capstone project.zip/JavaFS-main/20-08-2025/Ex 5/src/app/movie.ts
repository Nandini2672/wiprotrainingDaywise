export interface Movie {
    movieId:string;
    movieName:string;
    movieLanguage:string;
    imdbRating:number;
}
