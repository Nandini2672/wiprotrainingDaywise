import { CtfPipe } from './ctf-pipe';

describe('CtfPipe', () => {
  it('create an instance', () => {
    const pipe = new CtfPipe();
    expect(pipe).toBeTruthy();
  });
});
