package JavaTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DemoTest2 {

	@Test
	void test() {
		assertTrue(true);
	}

}
