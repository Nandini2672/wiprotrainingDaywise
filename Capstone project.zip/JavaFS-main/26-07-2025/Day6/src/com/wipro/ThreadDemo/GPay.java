package com.wipro.ThreadDemo;

public class GPay implements Payment{

	@Override
	public void payment() {
		System.out.println("Paid througn G pay");
		
	}

}
