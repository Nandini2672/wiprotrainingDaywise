package com.wipro.ThreadDemo;

public class PPay implements Payment{

	@Override
	public void payment() {
		System.out.println("Paid through Phone Pay");
		
	}

}
