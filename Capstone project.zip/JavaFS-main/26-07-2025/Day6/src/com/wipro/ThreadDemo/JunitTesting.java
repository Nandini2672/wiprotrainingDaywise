package com.wipro.ThreadDemo;

public class JunitTesting {
	String s = null;
	public boolean isupper(String s) {
		if(s.equals(s.toUpperCase())) {
			return true;
		}
		return false;
	}

}
