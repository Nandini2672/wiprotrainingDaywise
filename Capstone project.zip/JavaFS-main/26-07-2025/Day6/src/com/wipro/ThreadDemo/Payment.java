package com.wipro.ThreadDemo;

public interface Payment {
	public void payment();

}
