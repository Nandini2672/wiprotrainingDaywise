import { Component } from '@angular/core';

@Component({
  selector: 'app-secondcomp',
  imports: [],
  templateUrl: './secondcomp.html',
  styleUrl: './secondcomp.css'
})
export class Secondcomp {

}
