import { Component } from '@angular/core';

@Component({
  selector: 'app-thirdcomp',
  imports: [],
  // templateUrl: './thirdcomp.html',
  // Ex6
  template:`<h2>This is a new component</h2>
  <p>Inline HTML</p>`,
  styleUrl: './thirdcomp.css'
})
export class Thirdcomp {

}
