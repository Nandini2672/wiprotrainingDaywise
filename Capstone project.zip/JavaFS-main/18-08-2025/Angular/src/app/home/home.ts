import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  imports: [],
  templateUrl: './home.html',
  styleUrl: './home.css'
  
})
export class Home {
 books = [
    { title: 'Book 1', image: 'https://m.media-amazon.com/images/I/71XEsXS5RlL._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 2', image: 'https://m.media-amazon.com/images/I/712K3sdLlRL._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 3', image: 'https://m.media-amazon.com/images/I/715qi-cIbML._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 4', image: 'https://m.media-amazon.com/images/I/81JJ7fyyKyS._AC_UY327_QL65_.jpg', desc: 'Sample book' },
    { title: 'Book 5', image: 'https://m.media-amazon.com/images/I/617lxveUjYL._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 1', image: 'https://m.media-amazon.com/images/I/71XEsXS5RlL._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 2', image: 'https://m.media-amazon.com/images/I/712K3sdLlRL._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 3', image: 'https://m.media-amazon.com/images/I/715qi-cIbML._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 4', image: 'https://m.media-amazon.com/images/I/81JJ7fyyKyS._AC_UY327_QL65_.jpg', desc: 'Sample book' },
    { title: 'Book 5', image: 'https://m.media-amazon.com/images/I/617lxveUjYL._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 1', image: 'https://m.media-amazon.com/images/I/71XEsXS5RlL._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 2', image: 'https://m.media-amazon.com/images/I/712K3sdLlRL._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 3', image: 'https://m.media-amazon.com/images/I/715qi-cIbML._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 4', image: 'https://m.media-amazon.com/images/I/81JJ7fyyKyS._AC_UY327_QL65_.jpg', desc: 'Sample book' },
    { title: 'Book 5', image: 'https://m.media-amazon.com/images/I/617lxveUjYL._AC_UY218_.jpg', desc: 'Sample book' },
  { title: 'Book 1', image: 'https://m.media-amazon.com/images/I/71XEsXS5RlL._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 2', image: 'https://m.media-amazon.com/images/I/712K3sdLlRL._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 3', image: 'https://m.media-amazon.com/images/I/715qi-cIbML._AC_UY218_.jpg', desc: 'Sample book' },
    { title: 'Book 4', image: 'https://m.media-amazon.com/images/I/81JJ7fyyKyS._AC_UY327_QL65_.jpg', desc: 'Sample book' },
    { title: 'Book 5', image: 'https://m.media-amazon.com/images/I/617lxveUjYL._AC_UY218_.jpg', desc: 'Sample book' },
  
  ];
}
