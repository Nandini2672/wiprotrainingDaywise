export interface IVehicle {
    "id":string,
    "make":string,
    "model":string,
    "fuelType":string,
    "price":number
}

