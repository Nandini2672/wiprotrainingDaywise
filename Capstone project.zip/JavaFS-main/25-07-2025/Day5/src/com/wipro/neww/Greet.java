package com.wipro.neww;

@FunctionalInterface
public interface Greet {
	void sayHello();

}
