package com.wipro.neww;
//Functional interfaces are by default public
@FunctionalInterface
public interface Multiply {
	int multiply(int a, int b);
}
