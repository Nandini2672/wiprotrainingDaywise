package com.wipro.neww;

public interface BankOps {
	void deposit( double amount);
	
}
