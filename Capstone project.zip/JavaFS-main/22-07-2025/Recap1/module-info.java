
module Day6 {
}