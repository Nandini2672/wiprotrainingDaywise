package com.wipro.paymentmicro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentmicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentmicroApplication.class, args);
	}

}
