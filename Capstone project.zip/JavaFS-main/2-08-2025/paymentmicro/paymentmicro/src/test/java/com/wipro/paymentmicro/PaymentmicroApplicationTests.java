package com.wipro.paymentmicro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentmicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
