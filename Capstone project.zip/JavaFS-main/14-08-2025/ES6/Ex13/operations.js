export const multiply =(a,b)=>{
    return a*b;
}
export const divide = (a,b)=>{
    if(b ==0){
        return "Cannot divide by zero"
    }
    return a/b;
}
