import { multiply, divide } from "./operations.js";

console.log(multiply(2, 3)); 
console.log(divide(24, 2));   
console.log(divide(8, 0));   