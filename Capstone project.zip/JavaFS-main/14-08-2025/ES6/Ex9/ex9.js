const num =[1,2,3]
const sum=(a,b,c)=>{
    return a+b+c
}
console.log(sum(...num));