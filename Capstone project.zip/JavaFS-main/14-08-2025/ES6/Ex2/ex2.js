let arr = [1,2,3,4];
const doubleNumbers = (arr)=>{
    let doubledNumbers = arr.map(a =>a*2);
    console.log(doubledNumbers)
}
doubleNumbers(arr);