import User from "./user.js";

const user = new User("Nikita")
console.log(user.getName())