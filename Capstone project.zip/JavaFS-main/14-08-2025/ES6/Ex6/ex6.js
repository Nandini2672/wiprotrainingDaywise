const movie ={
    movieName :"War 2",
    movieLanguage :"Hindi",
    imdbRating : 8
}

const {movieName, movieLanguage, imdbRating} = movie;
console.log(`Movie name is ${movieName}`);
console.log(`Movie language is ${movieLanguage}`);
console.log(`Movie rating is ${imdbRating}`);
