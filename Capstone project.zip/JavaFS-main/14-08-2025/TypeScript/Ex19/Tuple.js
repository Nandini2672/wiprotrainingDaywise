var myData = [1, "Typescript", true];
console.log(myData);
