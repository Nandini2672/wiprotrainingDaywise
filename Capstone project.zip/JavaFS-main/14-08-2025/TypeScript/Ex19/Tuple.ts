let myData:[number, string ,boolean]=[1,"Typescript", true];
console.log(myData);