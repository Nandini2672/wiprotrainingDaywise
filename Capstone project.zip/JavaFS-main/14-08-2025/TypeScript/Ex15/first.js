var y = 10;
console.log(y);
