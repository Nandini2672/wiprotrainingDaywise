let y:number = 10
console.log(y);